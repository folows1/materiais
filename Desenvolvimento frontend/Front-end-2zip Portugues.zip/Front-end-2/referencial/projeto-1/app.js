console.log(document.body)

document.querySelector('h1').textContent = "ESALQ"
document.title = "MBA"

let h3 = document.createElement('h3')
h3.textContent = "cursos"
document.body.appendChild(h3)
