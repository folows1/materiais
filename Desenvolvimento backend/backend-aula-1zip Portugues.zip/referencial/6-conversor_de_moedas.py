taxa_euro = 5.55
taxa_iene = 30.19
valor_real = float(input('Digite o valor em R$: '))
print(f'Euro: {taxa_euro * valor_real:.2f} | Iene: {taxa_iene * valor_real:.2f}')