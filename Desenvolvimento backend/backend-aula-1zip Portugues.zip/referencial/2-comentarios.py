# comentário de apenas uma única linha

''''
Este é um comentário
que pode ter mais de 
uma linha e nada será exibido no console.
'''

"""
Este
também 
funciona em 
muitas linhas.
"""