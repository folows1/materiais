# 🐳 Ambiente de Desenvolvimento: PostgreSQL + pgAdmin (Docker)

Este projeto configura um ambiente de banco de dados completo, isolado e
agnóstico (Windows/Linux/Mac) utilizando Docker. Ele sobe
automaticamente:

- **PostgreSQL 16:** Banco de dados relacional\
- **pgAdmin 4:** Interface web para gerenciamento do banco

---

## 📋 Pré-requisitos

- Docker Desktop instalado e em execução.

---

## ⚙️ Configuração e Arquivos

Para rodar este ambiente, a estrutura de pastas deve ser exatamente
esta:

```text
/ (raiz do projeto)
├── .env                  # Credenciais e variáveis
├── docker-compose.yml    # Orquestração dos serviços
└── postgres-init/        # Scripts SQL automáticos
    └── init.sql          # Cria tabela e insere dados iniciais
```

---

### 1️⃣ Arquivo `.env`

Crie um arquivo chamado `.env` na raiz:

```ini
# Credenciais do Banco (Postgres)
POSTGRES_USER=admin
POSTGRES_PASSWORD=admin123
POSTGRES_DB=empresa

# Credenciais do pgAdmin (Interface Web)
PGADMIN_DEFAULT_EMAIL=admin@admin.com
PGADMIN_DEFAULT_PASSWORD=admin123
```

---

### 2️⃣ Arquivo `docker-compose.yml`

Crie este arquivo na raiz:

```yaml
version: "3.9"

services:
  postgres:
    image: postgres:16
    container_name: postgres_db
    restart: always
    env_file:
      - .env
    ports:
      - "5435:5432" # Porta Externa (PC) : Porta Interna (Docker)
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./postgres-init:/docker-entrypoint-initdb.d

  pgadmin:
    image: dpage/pgadmin4:latest
    container_name: pgadmin
    restart: always
    env_file:
      - .env
    ports:
      - "5050:80"
    depends_on:
      - postgres
    volumes:
      - pgadmin_data:/var/lib/pgadmin

volumes:
  postgres_data:
  pgadmin_data:
```

---

### 3️⃣ Arquivo `postgres-init/init.sql`

Dentro da pasta `postgres-init`, verifique o arquivo `init.sql`:

---

## 🚀 Como Executar

No terminal, na pasta do projeto:

```bash
docker compose up -d
```

O Docker irá baixar as imagens e iniciar os serviços em segundo plano.

---

## 🔌 Como Conectar

### 🅰️ Via pgAdmin (Interface Web)

- Acesse: http://localhost:5050\
- Login: `admin@admin.com`\
- Senha: `admin123`

**Adicionar servidor:**

**Aba General** - Name: `Meu Banco`

**Aba Connection** - Host name/address: `postgres` ⚠️\

- Port: `5432`\
- Username: `admin`\
- Password: `admin123`

---

### 🅱️ Via DBeaver, VSCode ou Terminal

Conexão externa ao Docker:

- Host: `localhost`\
- Port: `5435`\
- Database: `empresa`\
- User: `admin`\
- Password: `admin123`

---

## 🛠️ Comandos Úteis

---

Ação Comando Descrição

---

Ver Logs `docker compose logs -f` Acompanha logs em tempo real

Parar `docker compose stop` Para os serviços mantendo
dados

Reiniciar `docker compose restart` Reinicia os containers

Derrubar `docker compose down` Remove containers e redes

Resetar `docker compose down -v` ⚠️ Apaga tudo (inclusive o
banco)

---

---

## ❓ Solução de Problemas

**Erro de porta em uso**\
Se a porta 5435 estiver ocupada, altere no `docker-compose.yml` (ex:
`5436:5432`) e rode novamente.

**pgAdmin não conecta**\
Verifique se o _Host name_ está como `postgres`. Containers se comunicam
pelo nome do serviço, não por `localhost`.
