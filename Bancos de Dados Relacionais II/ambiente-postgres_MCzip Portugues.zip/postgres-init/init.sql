CREATE DOMAIN TIPO_CPF AS CHAR(11);

CREATE TABLE FUNCIONARIO ( 
  Pnome           VARCHAR(15) NOT NULL,
  Minicial        CHAR,
  Unome           VARCHAR(20) NOT NULL,
  Cpf             TIPO_CPF NOT NULL PRIMARY KEY,
  Datanasc        DATE,
  Endereco        VARCHAR(30),
  Sexo            CHAR(1) CHECK (Sexo = 'M' OR Sexo = 'F'),
  Salario         DECIMAL(7,2) DEFAULT 1045 CHECK (Salario >= 1045 AND Salario <= 60000),
  Cpf_supervisor  TIPO_CPF,
  Dnr             INT NOT NULL
);

CREATE TABLE DEPARTAMENTO ( 
  Dnome                VARCHAR(20) NOT NULL UNIQUE,
  Dnumero              INT NOT NULL PRIMARY KEY,
  Cpf_gerente          TIPO_CPF NOT NULL REFERENCES FUNCIONARIO(Cpf),
  Data_inicio_gerente  DATE
);

CREATE TABLE LOCALIZACAO_DEP ( 
  Dnumero         INT REFERENCES DEPARTAMENTO(Dnumero) ON DELETE CASCADE,
  Dlocal          VARCHAR(30),
  PRIMARY KEY (Dnumero, Dlocal)
);

CREATE TABLE PROJETO ( 
  Projnome        VARCHAR(20) NOT NULL UNIQUE,
  Projnumero      INT PRIMARY KEY,
  Projlocal       VARCHAR(30),
  Dnum            INT NOT NULL REFERENCES DEPARTAMENTO(Dnumero)
);

CREATE TABLE TRABALHA_EM ( 
  Fcpf            TIPO_CPF REFERENCES FUNCIONARIO(Cpf) ON DELETE CASCADE,
  Pnr             INT REFERENCES PROJETO(Projnumero) ON DELETE CASCADE,
  Horas           DECIMAL(3,1) NOT NULL,
  PRIMARY KEY (Fcpf, Pnr) 
);

CREATE TABLE DEPENDENTE ( 
  Fcpf             TIPO_CPF REFERENCES FUNCIONARIO(Cpf) ON DELETE CASCADE,
  Nome_dependente  VARCHAR(30),
  Sexo             CHAR,
  Datanasc         DATE,
  Parentesco       VARCHAR(8),
  PRIMARY KEY (Fcpf, Nome_dependente));


-- 1. INSERINDO FUNCIONÁRIOS (Gerentes e Supervisores primeiro para facilitar)
-- Departamentos planejados: 1 (Matriz), 4 (Administração), 5 (Pesquisa)

-- Presidente / Gerente Dept 1
INSERT INTO FUNCIONARIO (Pnome, Minicial, Unome, Cpf, Datanasc, Endereco, Sexo, Salario, Cpf_supervisor, Dnr)
VALUES ('Jorge', 'E', 'Brito', '88866555576', '1957-11-10', 'Rua do Horto, 450, SP', 'M', 55000.00, NULL, 1);

-- Gerente Dept 4
INSERT INTO FUNCIONARIO (Pnome, Minicial, Unome, Cpf, Datanasc, Endereco, Sexo, Salario, Cpf_supervisor, Dnr)
VALUES ('Jennifer', 'S', 'Souza', '98765432168', '1961-06-20', 'Av. Paulista, 1000, SP', 'F', 43000.00, '88866555576', 4);

-- Gerente Dept 5
INSERT INTO FUNCIONARIO (Pnome, Minicial, Unome, Cpf, Datanasc, Endereco, Sexo, Salario, Cpf_supervisor, Dnr)
VALUES ('Fernando', 'T', 'Wong', '33344555587', '1975-12-08', 'Rua da Lapa, 34, RJ', 'M', 40000.00, '88866555576', 5);

-- Demais Funcionários
INSERT INTO FUNCIONARIO (Pnome, Minicial, Unome, Cpf, Datanasc, Endereco, Sexo, Salario, Cpf_supervisor, Dnr)
VALUES ('Joao', 'B', 'Silva', '12345678966', '1985-01-09', 'Rua das Flores, 731, SP', 'M', 30000.00, '33344555587', 5);

INSERT INTO FUNCIONARIO (Pnome, Minicial, Unome, Cpf, Datanasc, Endereco, Sexo, Salario, Cpf_supervisor, Dnr)
VALUES ('Alice', 'J', 'Zelaya', '99988777767', '1988-01-19', 'Rua Curitiba, 3321, SP', 'F', 25000.00, '98765432168', 4);

INSERT INTO FUNCIONARIO (Pnome, Minicial, Unome, Cpf, Datanasc, Endereco, Sexo, Salario, Cpf_supervisor, Dnr)
VALUES ('Ronaldo', 'K', 'Lima', '66688444476', '1982-09-15', 'Rua Rebouças, 98, SP', 'M', 38000.00, '33344555587', 5);

INSERT INTO FUNCIONARIO (Pnome, Minicial, Unome, Cpf, Datanasc, Endereco, Sexo, Salario, Cpf_supervisor, Dnr)
VALUES ('Joice', 'A', 'Leite', '45345345376', '1992-07-31', 'Av. Lucas Obes, 77, SP', 'F', 25000.00, '33344555587', 5);

INSERT INTO FUNCIONARIO (Pnome, Minicial, Unome, Cpf, Datanasc, Endereco, Sexo, Salario, Cpf_supervisor, Dnr)
VALUES ('Andre', 'V', 'Pereira', '98798798733', '1989-03-29', 'Rua Timbiras, 33, SP', 'M', 22000.00, '98765432168', 4);

-- 2. INSERINDO DEPARTAMENTOS
-- Usando os CPFs dos gerentes criados acima

INSERT INTO DEPARTAMENTO (Dnome, Dnumero, Cpf_gerente, Data_inicio_gerente)
VALUES ('Matriz', 1, '88866555576', '2001-06-19');

INSERT INTO DEPARTAMENTO (Dnome, Dnumero, Cpf_gerente, Data_inicio_gerente)
VALUES ('Administracao', 4, '98765432168', '2015-01-01');

INSERT INTO DEPARTAMENTO (Dnome, Dnumero, Cpf_gerente, Data_inicio_gerente)
VALUES ('Pesquisa', 5, '33344555587', '2018-05-22');

-- 3. INSERINDO LOCALIZACAO_DEP

INSERT INTO LOCALIZACAO_DEP (Dnumero, Dlocal) VALUES (1, 'Sao Paulo');
INSERT INTO LOCALIZACAO_DEP (Dnumero, Dlocal) VALUES (4, 'Maua');
INSERT INTO LOCALIZACAO_DEP (Dnumero, Dlocal) VALUES (5, 'Santo Andre');
INSERT INTO LOCALIZACAO_DEP (Dnumero, Dlocal) VALUES (5, 'Itu');
INSERT INTO LOCALIZACAO_DEP (Dnumero, Dlocal) VALUES (5, 'Sao Paulo');

-- 4. INSERINDO PROJETOS

INSERT INTO PROJETO (Projnome, Projnumero, Projlocal, Dnum)
VALUES ('Produto X', 1, 'Santo Andre', 5);

INSERT INTO PROJETO (Projnome, Projnumero, Projlocal, Dnum)
VALUES ('Produto Y', 2, 'Itu', 5);

INSERT INTO PROJETO (Projnome, Projnumero, Projlocal, Dnum)
VALUES ('Produto Z', 3, 'Sao Paulo', 5);

INSERT INTO PROJETO (Projnome, Projnumero, Projlocal, Dnum)
VALUES ('Informatizacao', 10, 'Maua', 4);

INSERT INTO PROJETO (Projnome, Projnumero, Projlocal, Dnum)
VALUES ('Reorganizacao', 20, 'Sao Paulo', 1);

INSERT INTO PROJETO (Projnome, Projnumero, Projlocal, Dnum)
VALUES ('Novos Beneficios', 30, 'Maua', 4);

-- 5. INSERINDO TRABALHA_EM (Relacionando Funcionários e Projetos)

-- Joao Silva (Pesquisa) trabalha nos produtos X e Y
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('12345678966', 1, 32.5);
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('12345678966', 2, 7.5);

-- Fernando Wong (Gerente Pesquisa) trabalha nos produtos Y e Z, além de trabalhar na Informatização e Reorganização
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('33344555587', 2, 10.0);
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('33344555587', 3, 10.0);
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('33344555587', 10, 3.0); -- 
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('33344555587', 20, 2.0);

-- Jennifer Souza (Gerente Adm) trabalha na Informatização e Novos Benefícios
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('98765432168', 10, 35.0);
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('98765432168', 30, 5.0);

-- Ronaldo Lima (Pesquisa) trabalha no Produto Z
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('66688444476', 3, 40.0);

-- Joice Leite (Pesquisa) trabalha nos produtos X e Y
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('45345345376', 1, 20.0);
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('45345345376', 2, 20.0);

-- Alice Zelaya (Adm) trabalha na Informatização e Novos Benefícios
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('99988777767', 10, 10.0);
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('99988777767', 30, 30.0);

-- Andre Pereira (Adm) trabalha na Informatização e Reorganização
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('98798798733', 10, 25.0);
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('98798798733', 20, 5.0);

-- Jorge Brito (Presidente) - trabalha na Reorganização
INSERT INTO TRABALHA_EM (Fcpf, Pnr, Horas) VALUES ('88866555576', 20, 30.0);

-- 6. INSERINDO DEPENDENTES

INSERT INTO DEPENDENTE (Fcpf, Nome_dependente, Sexo, Datanasc, Parentesco)
VALUES ('33344555587', 'Alicia', 'F', '2006-04-05', 'Filha');

INSERT INTO DEPENDENTE (Fcpf, Nome_dependente, Sexo, Datanasc, Parentesco)
VALUES ('33344555587', 'Tiago', 'M', '2003-10-25', 'Filho');

INSERT INTO DEPENDENTE (Fcpf, Nome_dependente, Sexo, Datanasc, Parentesco)
VALUES ('33344555587', 'Janete', 'F', '1978-05-05', 'Esposa');

INSERT INTO DEPENDENTE (Fcpf, Nome_dependente, Sexo, Datanasc, Parentesco)
VALUES ('98765432168', 'Antonio', 'M', '1960-02-28', 'Marido');

INSERT INTO DEPENDENTE (Fcpf, Nome_dependente, Sexo, Datanasc, Parentesco)
VALUES ('12345678966', 'Michael', 'M', '2018-01-04', 'Filho');

INSERT INTO DEPENDENTE (Fcpf, Nome_dependente, Sexo, Datanasc, Parentesco)
VALUES ('12345678966', 'Alicia', 'F', '2018-12-30', 'Filha');

INSERT INTO DEPENDENTE (Fcpf, Nome_dependente, Sexo, Datanasc, Parentesco)
VALUES ('12345678966', 'Elizabeth', 'F', '1987-05-05', 'Esposa');

            
ALTER TABLE FUNCIONARIO
ADD FOREIGN KEY (Dnr) REFERENCES DEPARTAMENTO(DNumero);
