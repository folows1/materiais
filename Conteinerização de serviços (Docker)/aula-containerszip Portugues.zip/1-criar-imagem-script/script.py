# Texto que deve ser printado dentro do container
print("Esse script foi alterado")