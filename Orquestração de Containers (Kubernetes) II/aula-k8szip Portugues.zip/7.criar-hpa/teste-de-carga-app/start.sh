#! /bin/sh -c "

locust -f src/tasks.py --host http://servidor-python-service.default.svc.cluster.local